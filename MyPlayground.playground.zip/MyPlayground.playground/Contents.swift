import UIKit
import Darwin
// Write a program that prints your best friend's name.
var my_friends_name:String = "Nurlan"
print("My friend's name is \(my_friends_name)")

//Write a program that prints your name and your address in different lines.
var my_name:String = "Veysal"
var my_address:String = "Quba"
print("My name is \(my_name) \nMy address is \(my_address)")

/* Write a program that randomly select a number between 10 to 20.Print the division
by 4 of the number. */

var random_num:Int = Int.random(in: 10..<20)
print(random_num/4)


/* Write a program that randomly select a number between 0 to 100 to variable x and
prints:
a. a number smaller by 22
b. a number bigger by 22
c. the reminder of the division by 2 */

var a:Int = Int.random(in: 0..<100)
print(a-22)
print(a+22)
print(a%2)

/* Write a program that randomly select 3 numbers between 0 to 100 to x,y and z and
prints their sum */

var x = Int.random(in: 0..<100)
var y = Int.random(in: 0..<100)
var z = Int.random(in: 0..<100)


print("Sum is \(x+y+z)")
